rm -f /data/adb/ksu/bin/ksu_susfs

